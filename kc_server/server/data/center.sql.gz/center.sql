-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: center
-- ------------------------------------------------------
-- Server version	5.7.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dispatchlist`
--

DROP TABLE IF EXISTS `dispatchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dispatchlist` (
  `name` varchar(16) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '服务名称',
  `serverid` int(11) NOT NULL DEFAULT '0' COMMENT '服务器ID',
  `area` int(11) DEFAULT '0' COMMENT '所在分区',
  PRIMARY KEY (`name`,`serverid`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='服务器分配表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatchlist`
--

LOCK TABLES `dispatchlist` WRITE;
/*!40000 ALTER TABLE `dispatchlist` DISABLE KEYS */;
INSERT INTO `dispatchlist` VALUES ('httpp',1,1),('war',1,1),('world',1,1),('mainrecord',1,1),('httpr',1,1),('mainplat',1,1);
/*!40000 ALTER TABLE `dispatchlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodelist`
--

DROP TABLE IF EXISTS `nodelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodelist` (
  `name` varchar(16) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '服务名称',
  `area` int(11) NOT NULL DEFAULT '0' COMMENT '服务序号',
  `node` int(11) DEFAULT '0' COMMENT '跨服节点',
  PRIMARY KEY (`name`,`area`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='跨服节点列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodelist`
--

LOCK TABLES `nodelist` WRITE;
/*!40000 ALTER TABLE `nodelist` DISABLE KEYS */;
INSERT INTO `nodelist` VALUES ('war',1,8110),('world',1,8110);
/*!40000 ALTER TABLE `nodelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `server` varchar(128) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '服务名',
  `version` int(11) DEFAULT '0' COMMENT '版本号',
  `beforevs` int(11) DEFAULT '0' COMMENT '更新前的版本号',
  PRIMARY KEY (`server`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='版本号表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES ('center1',0,0);
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-07 14:41:25
