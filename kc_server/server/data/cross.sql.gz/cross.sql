-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: cross
-- ------------------------------------------------------
-- Server version	5.7.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version` (
  `server` varchar(128) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '服务名',
  `version` int(11) DEFAULT '0' COMMENT '版本号',
  `beforevs` int(11) DEFAULT '0' COMMENT '更新前的版本号',
  PRIMARY KEY (`server`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='版本号表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES ('world1_1',0,0),('war1_1',0,0);
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `war1_qualifying_player`
--

DROP TABLE IF EXISTS `war1_qualifying_player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `war1_qualifying_player` (
  `dbid` bigint(20) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `rank` int(2) DEFAULT '0' COMMENT '玩家赛场',
  `data` mediumblob COMMENT '玩家数据',
  PRIMARY KEY (`dbid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='仙道会玩家数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `war1_qualifying_player`
--

LOCK TABLES `war1_qualifying_player` WRITE;
/*!40000 ALTER TABLE `war1_qualifying_player` DISABLE KEYS */;
/*!40000 ALTER TABLE `war1_qualifying_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `war1_qualifying_record`
--

DROP TABLE IF EXISTS `war1_qualifying_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `war1_qualifying_record` (
  `no` int(11) NOT NULL DEFAULT '0' COMMENT '录像编号',
  `data` mediumblob COMMENT '战斗录像',
  PRIMARY KEY (`no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='仙道会战斗录像';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `war1_qualifying_record`
--

LOCK TABLES `war1_qualifying_record` WRITE;
/*!40000 ALTER TABLE `war1_qualifying_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `war1_qualifying_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `war1_wardatas`
--

DROP TABLE IF EXISTS `war1_wardatas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `war1_wardatas` (
  `uniquevalue` int(11) NOT NULL DEFAULT '1' COMMENT '类型唯一',
  `fieldboss` mediumblob COMMENT '野外boss',
  `publicboss` mediumblob COMMENT '全民boss',
  `guildboss` mediumblob COMMENT '帮会boss',
  `qualifying_audition` mediumblob COMMENT '仙道会_audition',
  `qualifying_auditionFight` mediumblob COMMENT '仙道会_auditionFight',
  `qualifying_rank` mediumblob COMMENT '仙道会_rank',
  `qualifying_key` mediumblob COMMENT '仙道会_key',
  `qualifying_last` mediumblob COMMENT '仙道会_last',
  `qualifying_the` mediumblob COMMENT '仙道会_the',
  `qualifying_bets` mediumblob COMMENT '仙道会bets',
  `climb` mediumblob COMMENT '九重天',
  `guildwar` mediumblob COMMENT '帮会战',
  `guildmine` mediumblob COMMENT '矿山争夺',
  `maincity` mediumblob COMMENT '主城地图',
  PRIMARY KEY (`uniquevalue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='战斗数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `war1_wardatas`
--

LOCK TABLES `war1_wardatas` WRITE;
/*!40000 ALTER TABLE `war1_wardatas` DISABLE KEYS */;
INSERT INTO `war1_wardatas` VALUES (1,_binary '{s008bosslist={},s008borntime=0}',_binary '{s008bosslist={1={s010killrecord={},s006iskill=b0,s010bosshp_pre=294259,s010bosshp_cur=294259,s010reborntime=0,s006bosshp=294259,s011attackinfos={},s008fightnum=0},2={s010killrecord={},s006iskill=b0,s010bosshp_pre=529666,s010bosshp_cur=529666,s010reborntime=0,s006bosshp=529666,s011attackinfos={},s008fightnum=0},3={s010killrecord={},s006iskill=b0,s010bosshp_pre=882776,s010bosshp_cur=882776,s010reborntime=0,s006bosshp=882776,s011attackinfos={},s008fightnum=0},4={s010killrecord={},s006iskill=b0,s010bosshp_pre=1353589,s010bosshp_cur=1353589,s010reborntime=0,s006bosshp=1353589,s011attackinfos={},s008fightnum=0},5={s010killrecord={},s006iskill=b0,s010bosshp_pre=1942105,s010bosshp_cur=1942105,s010reborntime=0,s006bosshp=1942105,s011attackinfos={},s008fightnum=0},6={s010killrecord={},s006iskill=b0,s010bosshp_pre=2648325,s010bosshp_cur=2648325,s010reborntime=0,s006bosshp=2648325,s011attackinfos={},s008fightnum=0},7={s010killrecord={},s006iskill=b0,s010bosshp_pre=3472248,s010bosshp_cur=3472248,s010reborntime=0,s006bosshp=3472248,s011attackinfos={},s008fightnum=0},8={s010killrecord={},s006iskill=b0,s010bosshp_pre=4413874,s010bosshp_cur=4413874,s010reborntime=0,s006bosshp=4413874,s011attackinfos={},s008fightnum=0},9={s010killrecord={},s006iskill=b0,s010bosshp_pre=5473203,s010bosshp_cur=5473203,s010reborntime=0,s006bosshp=5473203,s011attackinfos={},s008fightnum=0},10={s010killrecord={},s006iskill=b0,s010bosshp_pre=6532532,s010bosshp_cur=6532532,s010reborntime=0,s006bosshp=6532532,s011attackinfos={},s008fightnum=0},11={s010killrecord={},s006iskill=b0,s010bosshp_pre=7709564,s010bosshp_cur=7709564,s010reborntime=0,s006bosshp=7709564,s011attackinfos={},s008fightnum=0},12={s010killrecord={},s006iskill=b0,s010bosshp_pre=8886596,s010bosshp_cur=8886596,s010reborntime=0,s006bosshp=8886596,s011attackinfos={},s008fightnum=0},13={s010killrecord={},s006iskill=b0,s010bosshp_pre=10181331,s010bosshp_cur=10181331,s010reborntime=0,s006bosshp=10181331,s011attackinfos={},s008fightnum=0},14={s010killrecord={},s006iskill=b0,s010bosshp_pre=11476066,s010bosshp_cur=11476066,s010reborntime=0,s006bosshp=11476066,s011attackinfos={},s008fightnum=0},15={s010killrecord={},s006iskill=b0,s010bosshp_pre=12888504,s010bosshp_cur=12888504,s010reborntime=0,s006bosshp=12888504,s011attackinfos={},s008fightnum=0},16={s010killrecord={},s006iskill=b0,s010bosshp_pre=14300942,s010bosshp_cur=14300942,s010reborntime=0,s006bosshp=14300942,s011attackinfos={},s008fightnum=0},17={s010killrecord={},s006iskill=b0,s010bosshp_pre=15831083,s010bosshp_cur=15831083,s010reborntime=0,s006bosshp=15831083,s011attackinfos={},s008fightnum=0},18={s010killrecord={},s006iskill=b0,s010bosshp_pre=17361224,s010bosshp_cur=17361224,s010reborntime=0,s006bosshp=17361224,s011attackinfos={},s008fightnum=0},19={s010killrecord={},s006iskill=b0,s010bosshp_pre=19009068,s010bosshp_cur=19009068,s010reborntime=0,s006bosshp=19009068,s011attackinfos={},s008fightnum=0},20={s010killrecord={},s006iskill=b0,s010bosshp_pre=20656912,s010bosshp_cur=20656912,s010reborntime=0,s006bosshp=20656912,s011attackinfos={},s008fightnum=0},21={s010killrecord={},s006iskill=b0,s010bosshp_pre=22422460,s010bosshp_cur=22422460,s010reborntime=0,s006bosshp=22422460,s011attackinfos={},s008fightnum=0},22={s010killrecord={},s006iskill=b0,s010bosshp_pre=24188008,s010bosshp_cur=24188008,s010reborntime=0,s006bosshp=24188008,s011attackinfos={},s008fightnum=0},23={s010killrecord={},s006iskill=b0,s010bosshp_pre=26071259,s010bosshp_cur=26071259,s010reborntime=0,s006bosshp=26071259,s011attackinfos={},s008fightnum=0},24={s010killrecord={},s006iskill=b0,s010bosshp_pre=27954510,s010bosshp_cur=27954510,s010reborntime=0,s006bosshp=27954510,s011attackinfos={},s008fightnum=0},25={s010killrecord={},s006iskill=b0,s010bosshp_pre=29955464,s010bosshp_cur=29955464,s010reborntime=0,s006bosshp=29955464,s011attackinfos={},s008fightnum=0},26={s010killrecord={},s006iskill=b0,s010bosshp_pre=31956418,s010bosshp_cur=31956418,s010reborntime=0,s006bosshp=31956418,s011attackinfos={},s008fightnum=0},27={s010killrecord={},s006iskill=b0,s010bosshp_pre=34075075,s010bosshp_cur=34075075,s010reborntime=0,s006bosshp=34075075,s011attackinfos={},s008fightnum=0},28={s010killrecord={},s006iskill=b0,s010bosshp_pre=36193732,s010bosshp_cur=36193732,s010reborntime=0,s006bosshp=36193732,s011attackinfos={},s008fightnum=0},29={s010killrecord={},s006iskill=b0,s010bosshp_pre=38430092,s010bosshp_cur=38430092,s010reborntime=0,s006bosshp=38430092,s011attackinfos={},s008fightnum=0},30={s010killrecord={},s006iskill=b0,s010bosshp_pre=40666452,s010bosshp_cur=40666452,s010reborntime=0,s006bosshp=40666452,s011attackinfos={},s008fightnum=0},31={s010killrecord={},s006iskill=b0,s010bosshp_pre=43020515,s010bosshp_cur=43020515,s010reborntime=0,s006bosshp=43020515,s011attackinfos={},s008fightnum=0},32={s010killrecord={},s006iskill=b0,s010bosshp_pre=45374578,s010bosshp_cur=45374578,s010reborntime=0,s006bosshp=45374578,s011attackinfos={},s008fightnum=0},33={s010killrecord={},s006iskill=b0,s010bosshp_pre=47846344,s010bosshp_cur=47846344,s010reborntime=0,s006bosshp=47846344,s011attackinfos={},s008fightnum=0},34={s010killrecord={},s006iskill=b0,s010bosshp_pre=50318110,s010bosshp_cur=50318110,s010reborntime=0,s006bosshp=50318110,s011attackinfos={},s008fightnum=0},35={s010killrecord={},s006iskill=b0,s010bosshp_pre=52907579,s010bosshp_cur=52907579,s010reborntime=0,s006bosshp=52907579,s011attackinfos={},s008fightnum=0},36={s010killrecord={},s006iskill=b0,s010bosshp_pre=55497048,s010bosshp_cur=55497048,s010reborntime=0,s006bosshp=55497048,s011attackinfos={},s008fightnum=0},37={s010killrecord={},s006iskill=b0,s010bosshp_pre=58204221,s010bosshp_cur=58204221,s010reborntime=0,s006bosshp=58204221,s011attackinfos={},s008fightnum=0},38={s010killrecord={},s006iskill=b0,s010bosshp_pre=60911394,s010bosshp_cur=60911394,s010reborntime=0,s006bosshp=60911394,s011attackinfos={},s008fightnum=0},39={s010killrecord={},s006iskill=b0,s010bosshp_pre=63736270,s010bosshp_cur=63736270,s010reborntime=0,s006bosshp=63736270,s011attackinfos={},s008fightnum=0},40={s010killrecord={},s006iskill=b0,s010bosshp_pre=66561146,s010bosshp_cur=66561146,s010reborntime=0,s006bosshp=66561146,s011attackinfos={},s008fightnum=0},41={s010killrecord={},s006iskill=b0,s010bosshp_pre=69503725,s010bosshp_cur=69503725,s010reborntime=0,s006bosshp=69503725,s011attackinfos={},s008fightnum=0},42={s010killrecord={},s006iskill=b0,s010bosshp_pre=72446304,s010bosshp_cur=72446304,s010reborntime=0,s006bosshp=72446304,s011attackinfos={},s008fightnum=0},43={s010killrecord={},s006iskill=b0,s010bosshp_pre=75506586,s010bosshp_cur=75506586,s010reborntime=0,s006bosshp=75506586,s011attackinfos={},s008fightnum=0},44={s010killrecord={},s006iskill=b0,s010bosshp_pre=78566868,s010bosshp_cur=78566868,s010reborntime=0,s006bosshp=78566868,s011attackinfos={},s008fightnum=0}}}',_binary '{s008bosslist={}}',_binary '{s003typ=0,s010memberList={},s008recordNo=1,s008audition={1={},2={},3={},4={}}}',_binary '{s013auditionFight={1={},2={},3={},4={}}}',_binary '{s012auditionRank={1={},2={},3={},4={}}}',_binary '{s007keyList={}}',_binary '{s008lastData={1={},2={},3={},4={}}}',_binary '{s004the2={1={},2={},3={},4={}},s005the16={1={},2={},3={},4={}},s004the4={1={},2={},3={},4={}},s004the8={1={},2={},3={},4={}}}',_binary '{s006bets16={1={},2={},3={},4={}},s005bets8={1={},2={},3={},4={}},s005bets4={1={},2={},3={},4={}},s005bets2={1={},2={},3={},4={}}}',_binary '{s009scorelist={},s008currrank={},s008champion={},s010recordlist={},s007session=1}',_binary '{s009champions={}}',_binary '{s011guildRecord={}}',_binary '{s008champion=0,s013worshipRecord={},s008worships={}}');
/*!40000 ALTER TABLE `war1_wardatas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `world1_activitys`
--

DROP TABLE IF EXISTS `world1_activitys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `world1_activitys` (
  `activity_id` int(11) NOT NULL DEFAULT '0' COMMENT '活动id',
  `activity_init_status` int(11) DEFAULT '0' COMMENT '开启标记',
  `activity_over_status` int(11) DEFAULT '0' COMMENT '结束标记',
  `activity_data` mediumblob COMMENT '活动数据',
  PRIMARY KEY (`activity_id`),
  KEY `type` (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='活动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world1_activitys`
--

LOCK TABLES `world1_activitys` WRITE;
/*!40000 ALTER TABLE `world1_activitys` DISABLE KEYS */;
/*!40000 ALTER TABLE `world1_activitys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `world1_auctions`
--

DROP TABLE IF EXISTS `world1_auctions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `world1_auctions` (
  `dbid` int(11) NOT NULL AUTO_INCREMENT COMMENT '索引ID',
  `playerid` bigint(20) DEFAULT '0' COMMENT '玩家ID',
  `playername` varchar(128) COLLATE utf8mb4_bin DEFAULT '' COMMENT '玩家名字',
  `guildid` bigint(20) DEFAULT '0' COMMENT '公会ID',
  `itemid` int(11) DEFAULT '0' COMMENT '物品ID',
  `count` int(11) DEFAULT '0' COMMENT '物品数量',
  `createtime` int(11) DEFAULT '0' COMMENT '创建时间',
  `status` int(11) DEFAULT '0' COMMENT '阶段',
  `price` mediumblob COMMENT '当前价格',
  `offerid` bigint(20) DEFAULT '0' COMMENT '当前出价者',
  `offername` varchar(128) COLLATE utf8mb4_bin DEFAULT '' COMMENT '当前出价者',
  `offertime` int(11) DEFAULT '0' COMMENT '出价时间',
  `dealtime` int(11) DEFAULT '0' COMMENT '成交时间',
  `isbuy` int(11) DEFAULT '0' COMMENT '是否是一口价',
  `dealprice` int(11) DEFAULT '0' COMMENT '一口价',
  `addprice` int(11) DEFAULT '0' COMMENT '增加值',
  `numerictype` int(11) DEFAULT '0' COMMENT '货币类型',
  `record` mediumblob COMMENT '出价记录',
  PRIMARY KEY (`dbid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='拍卖行';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world1_auctions`
--

LOCK TABLES `world1_auctions` WRITE;
/*!40000 ALTER TABLE `world1_auctions` DISABLE KEYS */;
/*!40000 ALTER TABLE `world1_auctions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `world1_ranks`
--

DROP TABLE IF EXISTS `world1_ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `world1_ranks` (
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '类型',
  `rank` int(11) NOT NULL DEFAULT '0' COMMENT '排名',
  `data` mediumblob COMMENT '数据',
  PRIMARY KEY (`type`,`rank`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='排行榜表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world1_ranks`
--

LOCK TABLES `world1_ranks` WRITE;
/*!40000 ALTER TABLE `world1_ranks` DISABLE KEYS */;
/*!40000 ALTER TABLE `world1_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `world1_worlddatas`
--

DROP TABLE IF EXISTS `world1_worlddatas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `world1_worlddatas` (
  `uniquevalue` int(11) NOT NULL DEFAULT '1' COMMENT '类型唯一',
  `record_activity` mediumblob COMMENT '后台推送活动表',
  PRIMARY KEY (`uniquevalue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='基础数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world1_worlddatas`
--

LOCK TABLES `world1_worlddatas` WRITE;
/*!40000 ALTER TABLE `world1_worlddatas` DISABLE KEYS */;
INSERT INTO `world1_worlddatas` VALUES (1,_binary '{s004list={}}');
/*!40000 ALTER TABLE `world1_worlddatas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-07 14:41:25
